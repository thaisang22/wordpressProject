			
			</div><!-- post-body-content -->

		</div><!-- #post-body .metabox-holder .columns-2 -->

		<br class="clear">	
	
	</div><!-- #poststuff -->

</div>