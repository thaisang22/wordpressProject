<div class="wrap">
	<h2><?php echo __( 'Woocommerce Products Slider Shortcodes', 'woo-products-slider-pro' ); ?></h2>
	<div id="poststuff">
		<div id="post-body" class="metabox-holder columns-2">
			<!-- main content -->
			<div id="post-body-content">